package trabajo_urgente;

public class Aplicacion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
			Empresa e = new Empresa(12345, "Instituto Tecnologico de Mexicali", "Lucia", null );
			System.out.println(e);
	}
	
}
