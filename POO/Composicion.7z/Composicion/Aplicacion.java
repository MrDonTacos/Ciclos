package tarea1_2;

public class Aplicacion {
public static void main(String[] args) {
Aplicacion app = new Aplicacion();
app.inicia();
}

public Aplicacion() {
	
}

public void inicia() {
/*System.out.println("La aplicacion ha iniciado...");*/
/*Coche c = new Coche();

/*System.out.println("El coche esta encendido:"+c.estaEncendido());


try {Thread.sleep(1000); c.enciende();} catch(InterruptedException e) {
}
System.out.println("El coche esta encendido:" +c.estaEncendido());

try {Thread.sleep(1000);c.apagado();} catch(InterruptedException e) {}

System.out.println("El estado del coche es:" +c.estaEncendido());


Persona p = new Persona("Paola");
Persona p2 = new Persona ("Pedro");
Coche c = new Coche();
	p.asignaCoche(c);
	p.viaja();
	p2.asignaCoche(c);
	p2.viaja();
	p.viaja();
	
	Motor m = new Motor();
	Coche c = new Coch
	
	e(m); 	
	c.acelera(m);
	c.enciende(m);
	for(int i=0;i<=20;i++) {
	c.acelera(m);}
	c.apagado(m);
	*/
	
	Persona p = new Persona("Saul");
	for(int i=0; i<20; i++) {
	p.emociona();}
	
}
}
